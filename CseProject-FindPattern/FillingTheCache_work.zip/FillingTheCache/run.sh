taskset -c 0x3 ./FillingTheCache
